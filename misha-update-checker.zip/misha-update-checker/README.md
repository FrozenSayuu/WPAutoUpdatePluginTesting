# WPAutoUpdatePluginTesting
Trying out a self-hosted plugin Update for Wordpress for LIA
